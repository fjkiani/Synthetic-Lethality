"""
DepMap data loader — downloads and caches all required matrices.

Strategy:
  1. Check disk cache first (parquet format for speed).
  2. Download from Figshare / DepMap portal on cache miss.
  3. Expose typed DataFrames to the analysis layer.

Cell-line ID convention: DepMap uses "ACH-XXXXXX" model IDs.
"""
from __future__ import annotations

import io
import logging
from pathlib import Path
from typing import Optional, Tuple

import httpx
import pandas as pd

from ..core.config import get_settings

logger = logging.getLogger(__name__)
cfg = get_settings()

# ── Helpers ───────────────────────────────────────────────────────────────────

def _cache_path(name: str) -> Path:
    return cfg.depmap_cache_dir / f"{name}.parquet"


def _load_or_download(
    name: str,
    url: str,
    index_col: Optional[str] = None,
    transpose: bool = False,
) -> pd.DataFrame:
    """Return a DataFrame, using disk cache when available."""
    cache = _cache_path(name)
    if cache.exists():
        logger.info("Cache hit: %s", name)
        return pd.read_parquet(cache)

    logger.info("Downloading %s from %s …", name, url)
    response = httpx.get(url, follow_redirects=True, timeout=300)
    response.raise_for_status()

    content = response.content
    try:
        df = pd.read_csv(io.BytesIO(content), index_col=0, low_memory=False)
    except Exception:
        df = pd.read_csv(io.BytesIO(content), low_memory=False)

    if transpose:
        df = df.T
    if index_col and index_col in df.columns:
        df = df.set_index(index_col)

    df.to_parquet(cache, index=True)
    logger.info("Saved %s → %s", name, cache)
    return df


# ── Public loaders ────────────────────────────────────────────────────────────

def load_crispr_gene_effect() -> pd.DataFrame:
    """
    Returns: DataFrame shape (n_cell_lines, n_genes).
    Rows = ACH model IDs, Columns = 'GENE (ENTREZ)' format or plain symbols.
    Chronos scores: more negative = more essential.
    """
    df = _load_or_download("crispr_gene_effect", cfg.depmap_crispr_url)
    # Normalise column names: strip ENTREZ suffix → plain gene symbols
    df.columns = [c.split(" (")[0] if " (" in c else c for c in df.columns]
    return df


def load_mutations() -> pd.DataFrame:
    """
    Returns: long-format MAF-style DataFrame with columns including
    ModelID, HugoSymbol, VariantClassification, etc.
    """
    return _load_or_download("mutations", cfg.depmap_mutation_url)


def load_cna() -> pd.DataFrame:
    """
    Returns: DataFrame shape (n_cell_lines, n_genes).
    Values = relative copy number (log2 ratio centred at 0).
    """
    df = _load_or_download("cna", cfg.depmap_cna_url)
    df.columns = [c.split(" (")[0] if " (" in c else c for c in df.columns]
    return df


def load_expression() -> pd.DataFrame:
    """
    Returns: DataFrame shape (n_cell_lines, n_genes).
    Values = log2(TPM+1).
    """
    df = _load_or_download("expression", cfg.depmap_expression_url)
    df.columns = [c.split(" (")[0] if " (" in c else c for c in df.columns]
    return df


def load_sample_info() -> pd.DataFrame:
    """
    Returns: DataFrame indexed by ModelID with lineage, subtype, etc.
    Key columns: ModelID, OncotreeLineage, OncotreePrimaryDisease,
                 OncotreeSubtype, Age, Sex, PrimaryOrMetastasis.
    """
    df = _load_or_download("sample_info", cfg.depmap_sample_info_url)
    if "ModelID" in df.columns:
        df = df.set_index("ModelID")
    return df


def load_prism_viability() -> pd.DataFrame:
    """
    Returns: DataFrame shape (n_cell_lines, n_compounds).
    Values = log2-fold-change viability (PRISM LFC).
    """
    return _load_or_download("prism_viability", cfg.depmap_prism_url)


def load_prism_meta() -> pd.DataFrame:
    """
    Returns: compound metadata DataFrame.
    Key columns: column_name, name, target, moa, phase, smiles.
    """
    return _load_or_download("prism_meta", cfg.depmap_prism_meta_url)


# ── Stratification helpers ─────────────────────────────────────────────────────

def get_mutant_wt_lines(
    gene: str,
    mutation_df: pd.DataFrame,
    sample_info: pd.DataFrame,
    cancer_type: Optional[str] = None,
    mutation_type: str = "any_mutation",
    cna_df: Optional[pd.DataFrame] = None,
    homdel_threshold: float = -1.0,
    amp_threshold: float = 1.0,
) -> Tuple[list, list]:
    """
    Split cell lines into mutant vs WT groups for a query gene.

    mutation_type options:
        'loss_of_function'      – damaging SNVs/indels (splice, nonsense, frameshift, missense-damaging)
        'gain_of_function'      – missense activating
        'homozygous_deletion'   – CNA < homdel_threshold
        'amplification'         – CNA > amp_threshold
        'any_mutation'          – any non-silent mutation

    Returns: (mutant_ids, wt_ids)
    """
    # Filter by cancer type first
    if cancer_type:
        lineage_cols = [
            c for c in sample_info.columns
            if c in ("OncotreeLineage", "OncotreePrimaryDisease", "OncotreeSubtype",
                     "lineage", "primary_disease", "Subtype")
        ]
        mask = pd.Series(False, index=sample_info.index)
        for col in lineage_cols:
            mask |= sample_info[col].str.contains(cancer_type, case=False, na=False)
        subset_lines = sample_info.index[mask].tolist()
    else:
        subset_lines = sample_info.index.tolist()

    if not subset_lines:
        raise ValueError(f"No cell lines found for cancer_type='{cancer_type}'")

    # Determine mutant lines
    if mutation_type in ("any_mutation", "loss_of_function", "gain_of_function"):
        # Work from mutation long-format table
        gene_col = next(
            (c for c in mutation_df.columns if c in ("HugoSymbol", "gene", "Gene_Symbol")),
            None,
        )
        model_col = next(
            (c for c in mutation_df.columns if c in ("ModelID", "DepMap_ID", "model_id")),
            None,
        )
        if gene_col is None or model_col is None:
            raise ValueError("Mutation table missing expected gene/model columns")

        gene_muts = mutation_df[mutation_df[gene_col] == gene]

        if mutation_type == "loss_of_function":
            lof_classes = {
                "Nonsense_Mutation", "Frame_Shift_Del", "Frame_Shift_Ins",
                "Splice_Site", "Splice_Region", "In_Frame_Del", "In_Frame_Ins",
                "Translation_Start_Site", "Nonstop_Mutation",
            }
            vc_col = next(
                (c for c in mutation_df.columns
                 if c in ("VariantClassification", "variant_classification", "Variant_Classification")),
                None,
            )
            if vc_col:
                gene_muts = gene_muts[gene_muts[vc_col].isin(lof_classes)]
        elif mutation_type == "gain_of_function":
            gene_muts = gene_muts[
                gene_muts.get("VariantAnnotation", pd.Series(dtype=str)).str.contains(
                    "gain.of.function|activating", case=False, na=False
                )
            ]

        mutant_ids = gene_muts[model_col].unique().tolist()

    elif mutation_type == "homozygous_deletion":
        if cna_df is None:
            raise ValueError("CNA matrix required for homozygous_deletion stratification")
        if gene not in cna_df.columns:
            raise ValueError(f"Gene {gene} not found in CNA matrix")
        mutant_ids = cna_df.index[cna_df[gene] < homdel_threshold].tolist()

    elif mutation_type == "amplification":
        if cna_df is None:
            raise ValueError("CNA matrix required for amplification stratification")
        if gene not in cna_df.columns:
            raise ValueError(f"Gene {gene} not found in CNA matrix")
        mutant_ids = cna_df.index[cna_df[gene] > amp_threshold].tolist()

    else:
        raise ValueError(f"Unknown mutation_type: {mutation_type}")

    # Intersect with cancer-type subset
    mutant_ids = [m for m in mutant_ids if m in subset_lines]
    wt_ids = [l for l in subset_lines if l not in mutant_ids]

    return mutant_ids, wt_ids
