# Synthetic Lethality Mapping Agent — Backend

A production-grade FastAPI backend that executes a 4-step synthetic lethality (SL)
pipeline against DepMap CRISPR screen data, PRISM drug screens, ChEMBL, and OncoKB.

---

## Architecture

```
sl_agent/
├── core/
│   ├── config.py           # Environment-driven settings (Pydantic)
│   ├── models.py           # Typed domain models (SLQueryInput → SLMapResult)
│   ├── sl_engine.py        # Step 1: SL computation (Wilcoxon, FDR, delta-dep)
│   ├── drug_mapper.py      # Step 2–3: PRISM + ChEMBL + OncoKB + rank scoring
│   ├── pathway_annotator.py # Pathway labels + SLIdR/SLAYER cross-validation
│   └── orchestrator.py     # Wires all layers; singleton data store
├── data/
│   └── depmap_loader.py    # Download/cache DepMap matrices (Figshare)
├── api/
│   ├── app.py              # FastAPI factory + lifespan + middleware
│   └── routes.py           # REST endpoints
├── tests/
│   ├── test_sl_engine.py
│   ├── test_drug_mapper.py
│   └── test_api.py
├── main.py
└── requirements.txt
```

---

## Pipeline Steps

### Step 1 — Candidate SL Partner Identification (`sl_engine.py`)
- Loads DepMap Chronos gene effect matrix
- Splits cell lines into **mutant vs WT** groups for the query gene
  - Supports: LOF mutation, GOF, homozygous deletion, amplification, any mutation
- Applies **cancer-type-specific** stratification (≥30 lines), falls back to pan-cancer
- For each candidate partner gene:
  - **Wilcoxon rank-sum test** (one-sided: mutant more dependent)
  - **BH FDR** multiple-testing correction
  - **Cohen's d** effect size
  - **Co-dependency** (Pearson r of dependency profiles)
- Filters by `fdr_cutoff` and `delta_dep_cutoff`
- Removes pan-essential genes (core fitness, ≥90% cell lines dependent)

### Step 2 — Drug Mapping (`drug_mapper.py`)
- **PRISM repurposing screen**: Wilcoxon on viability LFC, mutant vs WT
- **ChEMBL REST API**: inhibitor lookup by gene target, MoA, clinical phase
- **OncoKB API**: therapeutic evidence levels (requires `ONCOKB_API_TOKEN`)
- **GDSC annotation**: compound target metadata

### Step 3 — Ranking
Composite `rank_score` (0–1):
```
rank = 0.45 × sl_signal + 0.35 × drug_response_differential + 0.20 × druggability
```
Where:
- `sl_signal = |Δdependency| / 2 × (1 - FDR)`
- `drug_response = |Δviability| / 3 × (1 - drug_FDR)`
- `druggability = max(phase_score, oncokb_level_score)`

### Step 4 — Structured JSON Output
Returns `SLMapResult` with:
- `input_context` — gene, cancer type, scope, n lines, frequencies
- `sl_partners[]` — ranked SL genes with stats, pathways, framework support
- `gene_drug_pairs[]` — ranked drug candidates with PRISM + external evidence
- `cross_validation` — SLIdR / SLAYER / literature confirmed vs speculative pairs

---

## Setup

```bash
pip install -r requirements.txt

# Optional: OncoKB token for therapeutic evidence
export ONCOKB_API_TOKEN=your_token_here

# Run server (data downloads on first startup, ~2–5 min)
uvicorn sl_agent.api.app:app --reload --port 8000
```

---

## Usage

### POST `/api/v1/analyze`
```json
{
  "gene": "BRCA1",
  "mutation_type": "loss_of_function",
  "cancer_type": "Ovarian Cancer",
  "top_n_partners": 20,
  "top_n_drugs": 10,
  "fdr_cutoff": 0.25,
  "delta_dep_cutoff": 0.15,
  "include_pathway_context": true,
  "include_codependency": true
}
```

**mutation_type** options:
| Value | Description |
|-------|-------------|
| `any_mutation` | Any non-silent somatic mutation |
| `loss_of_function` | Nonsense, frameshift, splice, truncating |
| `gain_of_function` | Activating missense |
| `homozygous_deletion` | CNA log2 < -1.0 |
| `amplification` | CNA log2 > 1.0 |

### GET `/api/v1/genes?prefix=BRCA`
List all genes in the current CRISPR matrix.

### GET `/api/v1/cancer_types`
List available cancer lineages and primary diseases.

### POST `/api/v1/analyze/async`
Submit job, returns `job_id`. Poll `GET /api/v1/result/{job_id}`.

---

## Example Output (truncated)
```json
{
  "status": "success",
  "result": {
    "input_context": {
      "query_gene": "BRCA1",
      "mutation_type": "loss_of_function",
      "cancer_type": "Ovarian Cancer",
      "scope": "cancer_specific",
      "n_total_lines": 47,
      "n_mut_lines": 14,
      "n_wt_lines": 33,
      "depmap_release": "25Q2"
    },
    "sl_partners": [
      {
        "gene": "PARP1",
        "delta_dependency": -0.87,
        "p_value": 2.1e-05,
        "fdr": 0.0032,
        "n_mut": 14,
        "n_wt": 33,
        "test_type": "wilcoxon_ranksum_one_sided",
        "effect_size_cohend": -1.92,
        "pathway": ["DNA_Damage_Response"],
        "supporting_frameworks": { "SLIdR": true, "SLAYER": true, "literature": true }
      }
    ],
    "gene_drug_pairs": [
      {
        "partner_gene": "PARP1",
        "drug_name": "Olaparib",
        "drug_class": "PARP inhibitor",
        "depmap_evidence": {
          "dataset": "PRISM_repurposing",
          "delta_viability": -1.24,
          "p_value": 0.0004,
          "fdr": 0.018
        },
        "external_evidence": {
          "source": "OncoKB",
          "oncokb_level": "LEVEL_1",
          "max_phase": 4
        },
        "rank_score": 0.82
      }
    ],
    "cross_validation": {
      "frameworks_checked": ["SLIdR", "SLAYER", "SL_RFM_literature"],
      "confirmed_pairs": ["PARP1", "BRCA2"],
      "speculative_pairs": ["ATR", "CHEK1"]
    }
  }
}
```

---

## Configuration (`.env`)
```
DEPMAP_RELEASE=25Q2
ONCOKB_API_TOKEN=xxx
FDR_THRESHOLD=0.25
DELTA_DEP_THRESHOLD=0.15
MIN_CELL_LINES_CANCER_SPECIFIC=30
```

---

## Tests
```bash
pytest sl_agent/tests/ -v
# 19 tests, all offline (synthetic data, mocked APIs)
```

---

## Extension Points

| What | Where |
|------|--------|
| Add GDSC IC50 response data | `drug_mapper.py` → `gdsc_drugs_for_gene()` |
| Add MSigDB pathway sets | `pathway_annotator.py` → extend `PATHWAY_GENE_MAP` |
| Add SLIdR/SLAYER API calls | `pathway_annotator.py` → `_SLIDR_KNOWN` / `_SLAYER_KNOWN` |
| Add Redis job queue | `api/routes.py` → replace `_jobs` dict |
| Add TCGA mutation frequencies | `orchestrator.py` → after stratification |
| Add cGAS-STING pathway scoring | `pathway_annotator.py` → `Immune_Signaling_cGAS_STING` set |
