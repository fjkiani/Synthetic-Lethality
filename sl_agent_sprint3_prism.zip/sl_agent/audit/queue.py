"""
SQLite-backed audit queue for ReceiptCandidate lifecycle management.

Schema: single table `receipt_candidates` with all ReceiptCandidate fields.
DB file: configured via settings.audit_db_path (default: .cache/audit_queue.db)
Thread-safe: uses connection-per-call pattern (SQLite WAL mode).

No ORM — direct sqlite3 to keep zero new dependencies.
"""
from __future__ import annotations

import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from .models import ReceiptCandidate

logger = logging.getLogger(__name__)

# ── Coverage version cache (in-memory) ───────────────────────────────────────
# Simple flag invalidated on approve() / reject() / upsert() and after mine.
# Exposed via GET /audit/coverage as X-Coverage-Version header.
# Thread-safe write via _set_coverage_version(); reads are lock-free.
import threading
_coverage_version_lock = threading.Lock()
_coverage_version: str = datetime.utcnow().isoformat()  # initialised at import


def _set_coverage_version() -> str:
    """Stamp a new coverage version timestamp. Returns the new version string."""
    global _coverage_version
    with _coverage_version_lock:
        _coverage_version = datetime.utcnow().isoformat()
        return _coverage_version


def get_coverage_version() -> str:
    """Read current coverage version (no lock needed — string reads are atomic in CPython)."""
    return _coverage_version

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS receipt_candidates (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    gene              TEXT NOT NULL,
    axis              TEXT NOT NULL,
    cancer_type       TEXT,
    crispr_delta_dep  REAL,
    crispr_fdr        REAL,
    crispr_n_mutant   INTEGER,
    crispr_n_wt       INTEGER,
    prism_delta_auc   REAL,
    gdsc_delta_ic50   REAL,
    kb_clinical_hits  INTEGER DEFAULT 0,
    expression_corr   REAL,
    confidence_score  REAL NOT NULL,
    candidate_tier    TEXT NOT NULL,
    evidence_summary  TEXT NOT NULL,
    audit_status      TEXT NOT NULL DEFAULT 'pending',
    audit_notes       TEXT,
    audited_by        TEXT,
    audited_at        TEXT,
    generated_at      TEXT NOT NULL,
    promoted_to_frozen INTEGER NOT NULL DEFAULT 0,
    depmap_release    TEXT NOT NULL DEFAULT 'unknown',
    source_pipeline   TEXT NOT NULL DEFAULT 'receipt_miner_v1',
    UNIQUE(gene, axis, cancer_type)  -- prevent duplicate candidates
)
"""

_PRAGMA_WAL = "PRAGMA journal_mode=WAL"


def _get_db_path() -> Path:
    from sl_agent.core.config import get_settings
    cfg = get_settings()
    path = getattr(cfg, "audit_db_path", Path(".cache/audit_queue.db"))
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _conn() -> sqlite3.Connection:
    db = _get_db_path()
    con = sqlite3.connect(str(db), check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute(_PRAGMA_WAL)
    return con


def init_db() -> None:
    """Create table if it doesn't exist. Called at app startup."""
    with _conn() as con:
        con.execute(_CREATE_TABLE)
        con.commit()
    logger.info("Audit queue DB initialized at %s", _get_db_path())


def _row_to_candidate(row: sqlite3.Row) -> ReceiptCandidate:
    d = dict(row)
    d["promoted_to_frozen"] = bool(d["promoted_to_frozen"])
    if d.get("audited_at"):
        d["audited_at"] = datetime.fromisoformat(d["audited_at"])
    if d.get("generated_at"):
        d["generated_at"] = datetime.fromisoformat(d["generated_at"])
    return ReceiptCandidate(**d)


class AuditQueue:
    """Thread-safe audit queue operations (stateless — each call opens its own connection)."""

    @staticmethod
    def upsert(candidate: ReceiptCandidate) -> ReceiptCandidate:
        """
        Insert or update a candidate. Uses (gene, axis, cancer_type) as unique key.
        If a pending candidate already exists for this pair, updates confidence/evidence.
        Approved/rejected candidates are NOT overwritten by new mining runs.
        Returns the candidate with its DB-assigned id.
        """
        with _conn() as con:
            # Check if approved/rejected — don't overwrite human decisions
            existing = con.execute(
                "SELECT id, audit_status FROM receipt_candidates "
                "WHERE gene=? AND axis=? AND (cancer_type IS ? OR cancer_type=?)",
                (candidate.gene.upper(), candidate.axis,
                 candidate.cancer_type, candidate.cancer_type)
            ).fetchone()

            if existing and existing["audit_status"] in ("approved", "rejected"):
                # Return existing — don't stomp human decision
                return _row_to_candidate(
                    con.execute(
                        "SELECT * FROM receipt_candidates WHERE id=?",
                        (existing["id"],)
                    ).fetchone()
                )

            now = datetime.utcnow().isoformat()
            con.execute("""
                INSERT INTO receipt_candidates
                  (gene, axis, cancer_type, crispr_delta_dep, crispr_fdr,
                   crispr_n_mutant, crispr_n_wt, prism_delta_auc, gdsc_delta_ic50,
                   kb_clinical_hits, expression_corr, confidence_score,
                   candidate_tier, evidence_summary, audit_status,
                   generated_at, depmap_release, source_pipeline)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'pending',?,?,?)
                ON CONFLICT(gene, axis, cancer_type) DO UPDATE SET
                  crispr_delta_dep=excluded.crispr_delta_dep,
                  crispr_fdr=excluded.crispr_fdr,
                  confidence_score=excluded.confidence_score,
                  candidate_tier=excluded.candidate_tier,
                  evidence_summary=excluded.evidence_summary,
                  generated_at=excluded.generated_at
                WHERE receipt_candidates.audit_status = 'pending'
            """, (
                candidate.gene.upper(), candidate.axis, candidate.cancer_type,
                candidate.crispr_delta_dep, candidate.crispr_fdr,
                candidate.crispr_n_mutant, candidate.crispr_n_wt,
                candidate.prism_delta_auc, candidate.gdsc_delta_ic50,
                candidate.kb_clinical_hits, candidate.expression_corr,
                candidate.confidence_score, candidate.candidate_tier,
                candidate.evidence_summary, now,
                candidate.depmap_release, candidate.source_pipeline,
            ))
            con.commit()

            row = con.execute(
                "SELECT * FROM receipt_candidates WHERE gene=? AND axis=? AND (cancer_type IS ? OR cancer_type=?)",
                (candidate.gene.upper(), candidate.axis,
                 candidate.cancer_type, candidate.cancer_type)
            ).fetchone()
            return _row_to_candidate(row)

    @staticmethod
    def list_pending(
        min_confidence: float = 0.0,
        gene: Optional[str] = None,
        axis: Optional[str] = None,
        limit: int = 100,
    ) -> List[ReceiptCandidate]:
        """List pending candidates sorted by confidence descending."""
        clauses = ["audit_status = 'pending'", "confidence_score >= ?"]
        params: list = [min_confidence]
        if gene:
            clauses.append("gene = ?")
            params.append(gene.upper())
        if axis:
            clauses.append("axis = ?")
            params.append(axis)
        params.append(limit)
        with _conn() as con:
            rows = con.execute(
                f"SELECT * FROM receipt_candidates WHERE {' AND '.join(clauses)} "
                f"ORDER BY confidence_score DESC LIMIT ?",
                params,
            ).fetchall()
        return [_row_to_candidate(r) for r in rows]

    @staticmethod
    def get(candidate_id: int) -> Optional[ReceiptCandidate]:
        with _conn() as con:
            row = con.execute(
                "SELECT * FROM receipt_candidates WHERE id=?", (candidate_id,)
            ).fetchone()
        return _row_to_candidate(row) if row else None

    @staticmethod
    def approve(candidate_id: int, notes: Optional[str], audited_by: str) -> Optional[ReceiptCandidate]:
        """Mark a candidate as approved. Does NOT auto-promote to frozen receipts.
        Invalidates coverage version so the doctor portal heat map knows to refresh.
        """
        now = datetime.utcnow().isoformat()
        with _conn() as con:
            con.execute(
                "UPDATE receipt_candidates SET audit_status='approved', "
                "audit_notes=?, audited_by=?, audited_at=? WHERE id=?",
                (notes, audited_by, now, candidate_id)
            )
            con.commit()
            row = con.execute(
                "SELECT * FROM receipt_candidates WHERE id=?", (candidate_id,)
            ).fetchone()
        _set_coverage_version()  # invalidate coverage cache
        return _row_to_candidate(row) if row else None

    @staticmethod
    def reject(candidate_id: int, notes: Optional[str], audited_by: str) -> Optional[ReceiptCandidate]:
        """Mark a candidate as rejected.
        Invalidates coverage version so the doctor portal heat map knows to refresh.
        """
        now = datetime.utcnow().isoformat()
        with _conn() as con:
            con.execute(
                "UPDATE receipt_candidates SET audit_status='rejected', "
                "audit_notes=?, audited_by=?, audited_at=? WHERE id=?",
                (notes, audited_by, now, candidate_id)
            )
            con.commit()
            row = con.execute(
                "SELECT * FROM receipt_candidates WHERE id=?", (candidate_id,)
            ).fetchone()
        _set_coverage_version()  # invalidate coverage cache
        return _row_to_candidate(row) if row else None

    @staticmethod
    def stats() -> dict:
        with _conn() as con:
            total_pending = con.execute(
                "SELECT COUNT(*) FROM receipt_candidates WHERE audit_status='pending'"
            ).fetchone()[0]
            total_approved = con.execute(
                "SELECT COUNT(*) FROM receipt_candidates WHERE audit_status='approved'"
            ).fetchone()[0]
            total_rejected = con.execute(
                "SELECT COUNT(*) FROM receipt_candidates WHERE audit_status='rejected'"
            ).fetchone()[0]
            total_promoted = con.execute(
                "SELECT COUNT(*) FROM receipt_candidates WHERE promoted_to_frozen=1"
            ).fetchone()[0]
            high_conf = con.execute(
                "SELECT COUNT(*) FROM receipt_candidates WHERE audit_status='pending' AND confidence_score>=0.70"
            ).fetchone()[0]
        return {
            "total_pending": total_pending,
            "total_approved": total_approved,
            "total_rejected": total_rejected,
            "total_promoted": total_promoted,
            "high_confidence_pending": high_conf,
        }

    @staticmethod
    def coverage() -> List[dict]:
        """
        Return all (gene, axis) pairs tracked in the queue.
        Merged with frozen receipt counts from literature_receipts.
        Called by GET /audit/coverage.
        """
        from sl_agent.multimodal.literature_receipts import _FROZEN_RECEIPTS
        from sl_agent.multimodal.models import CandidateAxis

        # Axis label map
        axis_labels = {
            "cytidine_analogs": "Cytidine Analogs (gemcitabine, cytarabine)",
            "parp_inhibitors":  "PARP Inhibitors (olaparib, niraparib, talazoparib, rucaparib)",
            "atr_wee1":         "ATR / WEE1 Inhibitors (berzosertib, adavosertib, ceralasertib)",
            "wrn":              "WRN Helicase Inhibitors (VX-803, MRTX1719)",
            "immunotherapy":    "Immunotherapy / Checkpoint Inhibitors (PD-1/PD-L1)",
            "pkmyt1":           "PKMYT1 Kinase Inhibitors (RP-6306 class)",
        }

        # Build frozen receipt index: (gene, axis) → count + clinical flag
        frozen_index: dict = {}
        for (gene, axis_enum), receipts in _FROZEN_RECEIPTS.items():
            key = (gene.upper(), axis_enum.value)
            has_clinical = any(
                r.status.value == "positive"
                for k, r in receipts.items()
                if k == "clinical"
            )
            frozen_index[key] = {
                "count": frozen_index.get(key, {}).get("count", 0) + len(receipts),
                "has_clinical": has_clinical,
            }

        # Pull candidate aggregates from DB
        with _conn() as con:
            rows = con.execute("""
                SELECT gene, axis,
                       SUM(CASE WHEN audit_status='pending' THEN 1 ELSE 0 END) AS pending_count,
                       SUM(CASE WHEN audit_status='approved' THEN 1 ELSE 0 END) AS approved_count,
                       MAX(CASE WHEN audit_status='pending' THEN confidence_score ELSE NULL END) AS best_confidence,
                       MAX(candidate_tier) AS candidate_tier
                FROM receipt_candidates
                GROUP BY gene, axis
            """).fetchall()

        # Merge: frozen pairs + candidate pairs + all known axes for frozen genes
        all_pairs: dict = {}

        # Seed from frozen receipts
        for (gene, axis_val), info in frozen_index.items():
            key = (gene, axis_val)
            all_pairs[key] = {
                "gene": gene,
                "axis": axis_val,
                "axis_label": axis_labels.get(axis_val, axis_val),
                "tier": "Validated SL therapeutic lever" if info["has_clinical"] else "Strong candidate dependency axis",
                "frozen_receipt_count": info["count"],
                "candidate_count": 0,
                "approved_count": 0,
                "confidence": None,
                "has_clinical_evidence": info["has_clinical"],
            }

        # Overlay candidate data
        for row in rows:
            key = (row["gene"].upper(), row["axis"])
            if key not in all_pairs:
                all_pairs[key] = {
                    "gene": row["gene"].upper(),
                    "axis": row["axis"],
                    "axis_label": axis_labels.get(row["axis"], row["axis"]),
                    "tier": row["candidate_tier"] or "Mechanistic candidate only",
                    "frozen_receipt_count": 0,
                    "candidate_count": 0,
                    "approved_count": 0,
                    "confidence": None,
                    "has_clinical_evidence": False,
                }
            all_pairs[key]["candidate_count"] = row["pending_count"] or 0
            all_pairs[key]["approved_count"] = row["approved_count"] or 0
            all_pairs[key]["confidence"] = row["best_confidence"]

        return sorted(all_pairs.values(), key=lambda x: (x["gene"], x["axis"]))
