"""
Audit queue API — backend for the doctor portal.

All endpoints:
  - Tagged "Audit / Doctor Portal"
  - Include RUO wrapper: {"ruo": true, "disclaimer": "...", "data": ...}
  - Designed to feed three doctor portal views:
      View 1: Case view (GET /audit/queue filtered by gene)
      View 2: Audit queue (GET /audit/queue, POST /audit/{id}/approve|reject)
      View 3: Coverage heat map (GET /audit/coverage)

Endpoints:
  GET  /audit/queue              — list pending candidates (sortable, filterable)
  GET  /audit/stats              — queue summary counts
  GET  /audit/coverage           — gene × axis coverage grid (for heat map)
  POST /audit/seed               — inject a test candidate (dev/test only)
  GET  /audit/{id}               — single candidate detail
  POST /audit/{id}/approve       — mark approved (does NOT auto-promote)
  POST /audit/{id}/reject        — mark rejected

NOTE: Static paths (/queue, /stats, /coverage, /seed) MUST be declared BEFORE
      the dynamic /{candidate_id} route to avoid path conflicts.
"""
from __future__ import annotations

import logging
from typing import List, Optional

from fastapi import APIRouter, HTTPException, Query, status

from .models import (
    AuditAction,
    CoverageEntry,
    QueueStats,
    ReceiptCandidate,
    RUO_DISCLAIMER,
    RUOEnvelope,
)
from .queue import AuditQueue, init_db

logger = logging.getLogger(__name__)

audit_router = APIRouter(
    prefix="/audit",
    tags=["Audit / Doctor Portal"],
)

# Initialize DB on first import
try:
    init_db()
except Exception as e:
    logger.warning("Audit DB init deferred: %s", e)


def _wrap(data) -> dict:
    """Wrap response in RUO envelope."""
    return {"ruo": True, "disclaimer": RUO_DISCLAIMER, "data": data}


# ── GET /audit/queue ──────────────────────────────────────────────────────────
# MUST come before /{candidate_id}

@audit_router.get(
    "/queue",
    summary="List pending receipt candidates sorted by confidence",
    description=(
        "Returns pending candidates for human review. "
        "Feeds Doctor Portal View 2 (Audit Queue). "
        "Filter by gene for View 1 (Case View)."
    ),
)
async def list_queue(
    gene: Optional[str] = Query(None, description="Filter by gene (e.g. MBD4)"),
    axis: Optional[str] = Query(None, description="Filter by axis (e.g. atr_wee1)"),
    min_confidence: float = Query(0.0, ge=0.0, le=1.0, description="Minimum confidence score"),
    limit: int = Query(100, ge=1, le=500),
):
    candidates = AuditQueue.list_pending(
        min_confidence=min_confidence,
        gene=gene,
        axis=axis,
        limit=limit,
    )
    return _wrap([c.model_dump() for c in candidates])


# ── GET /audit/stats ──────────────────────────────────────────────────────────
# MUST come before /{candidate_id}

@audit_router.get(
    "/stats",
    summary="Audit queue summary statistics",
)
async def queue_stats():
    s = AuditQueue.stats()
    return _wrap(s)


# ── GET /audit/coverage ───────────────────────────────────────────────────────
# MUST come before /{candidate_id}

@audit_router.get(
    "/coverage",
    summary="Gene × axis coverage grid",
    description=(
        "Returns all (gene, axis) pairs with their current tier, frozen receipt count, "
        "pending candidate count, and best confidence score. "
        "Feeds the Atlas Panel 1 heat map and Doctor Portal View 3 (Coverage). "
        "Updates automatically as candidates are approved."
    ),
)
async def coverage_grid():
    entries = AuditQueue.coverage()
    return _wrap(entries)


# ── POST /audit/seed (dev/test only) ─────────────────────────────────────────
# MUST come before /{candidate_id}

@audit_router.post(
    "/seed",
    summary="Seed a test candidate (dev/test only)",
    description="Injects a ReceiptCandidate directly into the queue. Dev/test use only.",
    include_in_schema=True,  # set False in production
)
async def seed_candidate(candidate: ReceiptCandidate):
    saved = AuditQueue.upsert(candidate)
    return _wrap(saved.model_dump())


# ── GET /audit/{candidate_id} ─────────────────────────────────────────────────
# Dynamic route — MUST come AFTER all static routes

@audit_router.get(
    "/{candidate_id}",
    summary="Get single candidate detail",
)
async def get_candidate(candidate_id: int):
    c = AuditQueue.get(candidate_id)
    if not c:
        raise HTTPException(status_code=404, detail=f"Candidate {candidate_id} not found")
    return _wrap(c.model_dump())


# ── POST /audit/{candidate_id}/approve ───────────────────────────────────────

@audit_router.post(
    "/{candidate_id}/approve",
    summary="Approve a receipt candidate",
    description=(
        "Marks candidate as approved. Does NOT auto-promote to frozen receipts — "
        "human must explicitly run the promotion workflow. "
        "Once approved, the candidate will not be overwritten by future mining runs."
    ),
)
async def approve_candidate(candidate_id: int, action: AuditAction):
    updated = AuditQueue.approve(candidate_id, action.notes, action.audited_by)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Candidate {candidate_id} not found")
    return _wrap(updated.model_dump())


# ── POST /audit/{candidate_id}/reject ────────────────────────────────────────

@audit_router.post(
    "/{candidate_id}/reject",
    summary="Reject a receipt candidate",
    description="Marks candidate as rejected with auditor notes.",
)
async def reject_candidate(candidate_id: int, action: AuditAction):
    updated = AuditQueue.reject(candidate_id, action.notes, action.audited_by)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Candidate {candidate_id} not found")
    return _wrap(updated.model_dump())
