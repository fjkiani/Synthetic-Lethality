# INTEGRATION_SPRINT2.md — Receipt Miner (POST /audit/mine)

## Overview

Sprint 2 builds the **Receipt Miner** pipeline on top of Sprint 1's audit queue infrastructure. It introduces automated multi-signal evidence mining that scores `(gene, axis)` pairs and upserts candidates into the audit queue for human review.

**VALIDATED tier is NEVER auto-assigned.** All tier promotions require human approval via the doctor portal.

---

## Files Delivered

| File | Status | Description |
|------|--------|-------------|
| `sl_agent/data/gdsc_biomarker_loader.py` | NEW | GDSC1/2 dose-response loader with Mann-Whitney U stratification |
| `sl_agent/multimodal/receipt_miner.py` | NEW | Core receipt mining pipeline — composite scoring + AuditQueue upsert |
| `sl_agent/multimodal/tests/test_receipt_miner.py` | NEW | 32 offline tests (all signals mocked) |
| `sl_agent/audit/routes.py` | MODIFIED | Added POST /audit/mine endpoint |
| `sl_agent/audit/tests/test_audit.py` | MODIFIED | Added 2 /mine route tests |

---

## Architecture

### Signal Weights (sum = 1.0)

| Signal | Weight | Source |
|--------|--------|--------|
| CRISPR dependency | 0.35 | DepMap Chronos via SLEngine |
| GDSC drug sensitivity | 0.30 | Mann-Whitney U on LN_IC50 |
| KB clinical evidence | 0.25 | CIViC + CGI + JAX via kb_engine |
| Expression correlation | 0.10 | DepMap expression matrix |

### Tier Projection (SABOTAGE PROTECTION)

```
_project_tier(confidence, kb_hits):
  if confidence >= 0.70 AND kb_hits >= 3: → "Strong"
  elif confidence >= 0.50:               → "Mechanistic"
  else:                                  → "Insufficient"  [discarded, not queued]
```

**"Validated" is NEVER returned by `_project_tier()`.** This is enforced by `_VALID_CANDIDATE_TIERS = {"Strong", "Mechanistic", "Insufficient"}`.

### Gate: confidence < 0.40 → discard (not upserted)

---

## Key Design Decisions

### GDSC Download Strategy (Mars Approach)
The Sanger ANOVA biomarker files at cancerrxgene.org return HTTP 410. We download the raw fitted dose-response Excel files (GDSC1/GDSC2 at Sanger COG) and compute our own Mann-Whitney U test (`scipy.stats.mannwhitneyu, alternative="less"`). This gives us full control over the statistical test and stratification.

- **Cache**: parquet files at `cfg.gdsc_cache_dir` (default `.cache/gdsc/`)
- **NEVER raises**: `gdsc_biomarker_stratify()` catches all exceptions and returns `None`
- **GDSCResult**: plain `dataclass` (not Pydantic) — matches spec exactly

### POST /audit/mine Route Ordering
The `/mine` endpoint is declared **before** the `/{candidate_id}` dynamic route in `routes.py`. FastAPI matches routes in declaration order — without this, POST `/mine` would be intercepted by the dynamic `/{candidate_id}` GET route.

### DataStore Pattern
`DataStore` in `orchestrator.py` uses **class-level attributes** (`_crispr`, `_mutations`, etc.), not a `_instance` singleton. `_compute_crispr_score()` reads `DataStore._crispr` directly and returns `(0.0, None, None, None, None)` gracefully when data is not loaded (CI environment).

### Offline Tests
All 32 tests in `test_receipt_miner.py` mock every network-touching function:
- `_compute_crispr_score` — mocked tuple return
- `_compute_gdsc_score` — mocked tuple return
- `_compute_kb_score` — mocked tuple return
- `_compute_expression_score` — mocked float return
- `AuditQueue.upsert` — mocked to capture calls
- `load_gdsc1` / `load_gdsc2` — return empty or synthetic DataFrames
- `_get_cosmic_mutant_lines` — returns `([], [])` or synthetic lists

---

## BRCA1+PARP Canary Confidence Score

With all signals at maximum (mocked):
```
CRISPR score = 1.0  × 0.35 = 0.350
GDSC score   = 1.0  × 0.30 = 0.300
KB score     = 1.0  × 0.25 = 0.250
Expr score   = 1.0  × 0.10 = 0.100
─────────────────────────────────────
Confidence                  = 1.000
Tier (_project_tier)        = "Strong"  [NEVER "Validated"]
```

Test: `TestCompositeWeights::test_brca1_parp_canary_confidence` — PASSED

---

## SABOTAGE TEST

**SABOTAGE TEST PASSED: test_sabotage_validated_never_returned**

Located in `TestProjectTier` class in `test_receipt_miner.py`.

The test exhaustively calls `_project_tier()` with:
- `confidence` in `[0.0, 0.05, 0.10, ..., 1.0]` (21 values)
- `kb_hits` in `[0, 1, 2, 3, 5, 10, 50, 100]` (8 values)
- = 168 combinations total

Plus explicit max-input assertions:
- `_project_tier(1.0, 1000)` → `"Strong"` (never `"Validated"`)
- `_project_tier(1.0, 100)` → `"Strong"`

All 168 combinations assert `tier != "Validated"` and `tier in {"Strong", "Mechanistic", "Insufficient"}`.

---

## Test Results

```
158 passed, 0 failed
```

Breakdown:
- `test_api.py`: 5 tests (unchanged)
- `test_drug_mapper.py`: 6 tests (unchanged)
- `test_sl_engine.py`: 8 tests (unchanged)
- `test_kb.py`: 26 tests (unchanged)
- `test_multimodal.py`: 40 tests (unchanged)
- `test_rs_benchmark.py`: 11 tests (unchanged)
- `test_receipt_miner.py`: **32 tests (NEW)**
- `test_audit.py`: **30 tests (28 existing + 2 new /mine tests)**

Previous: 126 tests. Added: 32 new. Total: **158 tests**.

---

## API Endpoint

```
POST /audit/mine
```

**Query parameters** (both optional):
- `gene_panel` (list[str]): gene symbols — defaults to `DEFAULT_GENE_PANEL` (~30 genes)
- `axes` (list[str]): axis values — defaults to `DEFAULT_AXES` (6 axes)

**Response** (immediate, runs in background):
```json
{
  "ruo": true,
  "disclaimer": "Research use only...",
  "data": {
    "status": "running",
    "gene_count": 30,
    "axis_count": 6,
    "estimated_pairs": 180,
    "message": "Mining started. Check GET /audit/queue for results."
  }
}
```

**Route position**: declared before `/{candidate_id}` to avoid path conflicts.

---

## Integration Notes

- Sprint 1 files NOT modified except `audit/routes.py` (added `/mine`) and `audit/tests/test_audit.py` (added 2 tests)
- No new Python package dependencies — uses `scipy`, `numpy`, `pandas`, `httpx` (all existing)
- GDSC parquet cache created at `cfg.gdsc_cache_dir` on first download; subsequent calls use cache
- `mine_receipts()` is idempotent: re-running with same gene/axis only updates pending candidates, never overwrites approved/rejected human decisions
- The `CUSTOM` axis is always skipped by the miner (requires explicit human input)

---

## Zip Contents

```
sl_agent_sprint2_miner.zip
└── sl_patch_sprint2/
    ├── INTEGRATION_SPRINT2.md
    ├── sl_agent/
    │   ├── data/
    │   │   └── gdsc_biomarker_loader.py
    │   ├── multimodal/
    │   │   ├── receipt_miner.py
    │   │   └── tests/
    │   │       └── test_receipt_miner.py
    │   └── audit/
    │       ├── routes.py
    │       └── tests/
    │           └── test_audit.py
```
